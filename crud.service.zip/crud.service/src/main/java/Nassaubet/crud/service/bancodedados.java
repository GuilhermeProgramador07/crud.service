package Nassaubet.crud.service;

import java.util.ArrayList;
import java.util.List;

public class bancodedados {
    private static List<agenda> agendas = new ArrayList<>();

    public agenda criar(agenda agenda) {
        agenda.setId(agendas.size() + 1l);
        agendas.add(agenda);
        return agenda;
    }
}
