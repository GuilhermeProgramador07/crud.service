package Nassaubet.crud.service;

public interface agendaRepository {
}
